/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd;

import com.spectramd.products.focus.common.FocusDefaultLogInitializer;
import com.spectramd.products.focus.common.FocusLogger;
import com.spectramd.products.focus.common.utils.ThreadUtils;
import org.apache.commons.daemon.Daemon;
import org.apache.commons.daemon.DaemonContext;
import org.apache.commons.daemon.DaemonInitException;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 *
 * @author sathyaji.raja
 */
public class FocusInterfaceNew implements Daemon {

	private AbstractApplicationContext ctx = null;

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		try {
			ThreadUtils.initializeInheritableThread();

			FocusInterfaceNew instance = new FocusInterfaceNew();
			instance.start();

			long index = 0;
			while (true) {
				Thread.sleep(1000);
			}

//			instance.stop();
//			FocusConfig.getCurrentLogger().writeDebug("End: FocusDataIntegration method: main(..)");
		} catch (Exception ex) {
			FocusLogger.error("Error:  ", ex);
		}
	}

	@Override
	public void init(DaemonContext dc) throws DaemonInitException, Exception {

	}

	@Override
	public void start() throws Exception {

//		ThreadUtils.initializeInheritableThread();
//		2. Initialize the logger
		FocusDefaultLogInitializer init = new FocusDefaultLogInitializer();
		init.Initialize(null);
		FocusLogger.info("Logger Initialized");

		ctx = new FileSystemXmlApplicationContext("./config/applicationContext-camel.xml");
		ctx.start();
	}

	@Override
	public void stop() throws Exception {
		if (null != ctx) {
			ctx.stop();
		}
	}

	@Override
	public void destroy() {
		// do nothing
	}

}
