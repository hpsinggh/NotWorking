/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd;

import com.spectramd.products.focus.common.FocusConfigInitializer;
import com.spectramd.products.focus.common.FocusLogger;
import com.spectramd.products.focus.common.utils.ThreadUtils;
import org.apache.camel.Exchange;

/**
 *
 * @author siraj
 */
public class FocusInitializationBean {

	public FocusInitializationBean() {
	}

	/**
	 * This method will initialize Client config information
	 * @param clientId
	 * @param exchange
	 */
	public void initialize(String clientId, Exchange exchange) {

		try {
			ThreadUtils.initializeInheritableThread();
			System.out.println(" FocusInitializationBean start() " + clientId);

			ThreadUtils.set("FOCUS_CLIENTID", clientId);
			ThreadUtils.set("FOCUS_CLIENTPATH", clientId);

//			FocusContext fcsContext = new FocusContext();
//			ClientInfo clientInfo = (ClientInfo) fcsContext.getObject(CommonConstants.FOCUSCLIENT_PREFIX + clientId, CacheScope.APPLICATION);
			String configFile = ".\\" + clientId + "\\focusconfig.properties";
			FocusConfigInitializer.initialize(configFile);
			FocusLogger.info("Configuration Intialized");
//			FocusConfig.initialize(clientId, clientInfo.getMapConfig());

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
