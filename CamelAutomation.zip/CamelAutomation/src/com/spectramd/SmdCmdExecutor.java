/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd;

import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.utils.ProcessUtils;
import org.apache.camel.Exchange;
import org.apache.commons.lang.exception.ExceptionUtils;

/**
 *
 * @author sathyaji.raja
 */
public class SmdCmdExecutor {

	public int execute(String commandName, String workingDirectory,
			String arguments, Exchange exchange) {
		int result = 1;
		try {
			String[] args = arguments.split(",");
			result = ProcessUtils.cmdExecute(commandName, workingDirectory, args);
		} catch (Exception ex) {
			exchange.setProperty("__FOCUS_FILEMOVE_ERRORDETAILS__", ExceptionUtils.getFullStackTrace(ex));
			ex.printStackTrace();
		}

		if (result == 0) {
//            String resultString = exchange.getProperty("__FOCUS_JOB_PROCESSEDFILES__").toString();
//            resultString += (System.lineSeparator() + commandName);

			exchange.setProperty("__FOCUS_SOURCEPATH_NOTEMPTY__", Boolean.TRUE);
			exchange.setProperty("__FOCUS_JOB_EXECUTIONRESULT__", Boolean.TRUE);
			exchange.setProperty("__FOCUS_JOB_PROCESSEDFILES__", commandName);
			System.out.println("Command Execution Success - " + commandName);
		} else {
			FocusConfig.getCurrentLogger().writeInfo("Unable to execute " + commandName);
			exchange.setProperty("__FOCUS_SOURCEPATH_NOTEMPTY__", Boolean.FALSE);
			System.out.println("Command Execution Failure - " + commandName);
		}

		return result;

	}
}
