package com.spectramd.poc;

import java.util.ArrayList;
import java.util.List;

public class MeasureList {

	public List listFormation() {
		List<MeasureObject> list = new ArrayList<>();

		MeasureObject measureObject1 = new MeasureObject();
		measureObject1.setMeasureId(1);
		measureObject1.setMeasureCode("7654321");
		measureObject1.setMeasureName("MIPS_002");
		list.add(measureObject1);

		MeasureObject measureObject2 = new MeasureObject();
		measureObject2.setMeasureId(1);
		measureObject2.setMeasureCode("7654324");
		measureObject2.setMeasureName("MIPS_003");
		list.add(measureObject2);

		MeasureObject measureObject3 = new MeasureObject();
		measureObject3.setMeasureId(1);
		measureObject3.setMeasureCode("7654322");
		measureObject3.setMeasureName("MIPS_003");
		list.add(measureObject3);

		MeasureObject measureObject4 = new MeasureObject();
		measureObject4.setMeasureId(1);
		measureObject4.setMeasureCode("7654324");
		measureObject4.setMeasureName("MIPS_004");
		list.add(measureObject4);

		return list;
	}
}
