/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.smd.logger;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author heerendra.singh
 * Logger levels:- DEBUG,INFO,WARN,ERROR,FATAL
 */
public class TestLogger {
final static Logger logger= Logger.getLogger("TestLogger");
    public static void main(String[] args) {
        PropertyConfigurator.configure("log4j.properties");
        logger.debug("This is DEBUG");//message for the log
        logger.info("This is INFO");//to generate the log message
        logger.warn("This is WARN");
        logger.error("This is ERROR");
        logger.fatal("This is FATAL");
        
        
//            BasicConfigurator.configure();
//        for (int i = 1; i <= 10; i++) {
//            System.out.println("i=" + i);
//            log.info("i equals " + i);
//        }
    }
}
