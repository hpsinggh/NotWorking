package com.spectramd.poc;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author deepak.singhal
 */
@Controller
public class HelloRestController {

	@RequestMapping(value = "/hello", produces = "application/json")
	@ResponseBody
	public String convertJson() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		MeasureList measureList = new MeasureList();
		List list = measureList.listFormation();
		String jsonInString = gson.toJson(list);
		System.out.println(jsonInString);
		return jsonInString;
	}
}
