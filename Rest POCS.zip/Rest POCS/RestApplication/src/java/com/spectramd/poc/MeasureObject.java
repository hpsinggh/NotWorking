/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.poc;

/**
 *
 * @author deepak.singhal
 */
public class MeasureObject {

	private String measureName;
	private String measureCode;
	private int measureId;

	/**
	 * @return the measureName
	 */
	public String getMeasureName() {
		return measureName;
	}

	/**
	 * @param measureName the measureName to set
	 */
	public void setMeasureName(String measureName) {
		this.measureName = measureName;
	}

	/**
	 * @return the measureCode
	 */
	public String getMeasureCode() {
		return measureCode;
	}

	/**
	 * @param measureCode the measureCode to set
	 */
	public void setMeasureCode(String measureCode) {
		this.measureCode = measureCode;
	}

	/**
	 * @return the measureId
	 */
	public int getMeasureId() {
		return measureId;
	}

	/**
	 * @param measureId the measureId to set
	 */
	public void setMeasureId(int measureId) {
		this.measureId = measureId;
	}
}
