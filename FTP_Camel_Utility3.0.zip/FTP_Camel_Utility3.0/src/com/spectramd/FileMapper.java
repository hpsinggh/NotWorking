/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

/**
 *
 * @author heerendra.singh
 */
public class FileMapper implements RowMapper<FileDetails> {
   public FileDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
      FileDetails fileDetails = new FileDetails();
      fileDetails.setFileName(rs.getString("STRING_VAL"));
      fileDetails.setExecution_ID(rs.getInt("JOB_EXECUTION_ID"));
      return fileDetails;
   }
}
