/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd;

import com.spectramd.products.focus.agent.FocusArgConfigInitializer;
import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusDefaultLogInitializer;
import com.spectramd.products.focus.common.FocusLogger;
import com.spectramd.products.focus.common.utils.ThreadUtils;
import java.io.File;
import java.util.Iterator;
import java.util.List;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 *
 * @author heerendra.singh
 */
public class RouteProcessor implements Processor {

    private FileDAO fileDAO;
    static String fileName;

    public void setFileDAO(FileDAO fileDAO) {
        this.fileDAO = fileDAO;

    }

    @Override
    public void process(Exchange exchange) {
        FocusConfig.getCurrentLogger().writeDebug("Start: Camel Route Processor");
        File file = exchange.getIn().getBody(File.class);
        fileName=file.getName();
        System.out.println("Transferring file :" + file.getName());
        FocusConfig.getCurrentLogger().writeDebug("End: Camel Route Processor");
        //throw new NullPointerException();
    }
    }
