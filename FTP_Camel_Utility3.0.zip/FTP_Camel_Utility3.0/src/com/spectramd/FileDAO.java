package com.spectramd;

import com.spectramd.products.focus.common.FocusConfig;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.UUID;
import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

/**
 *
 * @author heerendra.singh
 */
public class FileDAO {

    private JdbcTemplate jdbcTemplate;
    private DataSource dataSource;
    private String maxJobInstanceIDQuery;
    private String jobInstanceQuery;
    private Long maxJobInstanceID;
    private String maxJobExecutionIDQuery;
    private Long maxJobExecutionID;
    private String jobExecutionQuery;
    private String jobExecutionParamQuery;
    private FileDetails fileDetails;
    private String statusUpdateQuery;
    private String jobEndTimeQuery;
    private String exitCodeQuery;
    private String exitMessageQuery;
    private String jobExecutionContextQuery;
    private String getFnameAndExecutionIDQuery;

    public void setGetFnameAndExecutionIDQuery(String getFnameAndExecutionIDQuery) {
        this.getFnameAndExecutionIDQuery = getFnameAndExecutionIDQuery;
    }
 
    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate = new JdbcTemplate(this.dataSource);
    }

    public void setMaxJobInstanceIDQuery(String maxJobInstanceIDQuery) {
        this.maxJobInstanceIDQuery = maxJobInstanceIDQuery;
    }

    public void setjobInstanceQuery(String jobInstanceQuery) {
        this.jobInstanceQuery = jobInstanceQuery;
    }

    public void setMaxJobExecutionIDQuery(String maxJobExecutionIDQuery) {
        this.maxJobExecutionIDQuery = maxJobExecutionIDQuery;
    }

    public void setJobExecutionQuery(String jobExecutionQuery) {
        this.jobExecutionQuery = jobExecutionQuery;
    }

    public void setJobExecutionParamQuery(String jobExecutionParamQuery) {
        this.jobExecutionParamQuery = jobExecutionParamQuery;
    }

    public void setFileDetails(FileDetails fileDetails) {
        this.fileDetails = fileDetails;
    }

    public void setStatusUpdateQuery(String statusUpdateQuery) {
        this.statusUpdateQuery = statusUpdateQuery;
    }

    public void setJobEndTimeQuery(String jobEndTimeQuery) {
        this.jobEndTimeQuery = jobEndTimeQuery;
    }

    public void setExitCodeQuery(String exitCodeQuery) {
        this.exitCodeQuery = exitCodeQuery;
    }

    public void setExitMessageQuery(String exitMessageQuery) {
        this.exitMessageQuery = exitMessageQuery;
    }

    public void setJobExecutionContextQuery(String jobExecutionContextQuery) {
        this.jobExecutionContextQuery = jobExecutionContextQuery;
    }

    public void createInstance() {
        insertJobExecution();
        insertJobExecutionContext();
        insertJobExecutionParam();
    }
//-------------------------------------------------------------------------------------------------------------------------------
    public void jobCompleted() {
        updateJobEndTime();
        updateJobEcecutionStatus("COMPLETED",maxJobExecutionID);
        updateExitCodeQuery("COMPLETED");
    }

    public void jobFailed(StringWriter errors,long JobExecutionID ) {
        updateJobEcecutionStatus("FAILED",JobExecutionID);
        updateExitCodeQuery("FAILED");
        updateExitMessageQuery(errors.toString());
        System.exit(1);
    }

    public void insertJobInstance() {
        FocusConfig.getCurrentLogger().writeDebug("Start: FileDAO method: insertJobInstance(..)");

        maxJobInstanceID = new Long(jdbcTemplate.queryForInt(maxJobInstanceIDQuery));
        maxJobInstanceID += 1;
        System.out.println("Job Instance Id: " + maxJobInstanceID);
        KeyHolder holder = new GeneratedKeyHolder();

        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(jobInstanceQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setLong(j++, maxJobInstanceID);
                ps.setInt(j++, 0);
                ps.setString(j++, "FILE TRANSFER");
                ps.setString(j++, UUID.randomUUID().toString().replaceAll("-", ""));
                return ps;
            }
        }, holder);

        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: insertJobInstance(..)");
    }

    public void insertJobExecution() {
        FocusConfig.getCurrentLogger().writeDebug("Start: FileDAO method: insertJobExecution(..)");
        maxJobExecutionID = new Long(jdbcTemplate.queryForInt(maxJobExecutionIDQuery));
        maxJobExecutionID += 1;
        System.out.println("Job Execution id: " + maxJobExecutionID);
        KeyHolder holder = new GeneratedKeyHolder();

        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(jobExecutionQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setLong(j++, maxJobExecutionID);
                ps.setInt(j++, 0);
                ps.setLong(j++, maxJobInstanceID);
                ps.setString(j++,"PROGRESS");
                return ps;
            }
        }, holder);

        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: insertJobExecution(..)");
    }
    public void insertJobExecutionContext()
    {
        FocusConfig.getCurrentLogger().writeDebug("Start: FileDAO method: insertJobExecutionContext(..)");

        KeyHolder holder = new GeneratedKeyHolder();
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(jobExecutionContextQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setLong(j++,maxJobExecutionID);
                ps.setString(j++,"{\"map\":[\"\"]}");
                return ps;
            }
        }, holder);

        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: insertJobExecutionContext(..)");
    }
    public void insertJobExecutionParam() {
        FocusConfig.getCurrentLogger().writeDebug("Start: FileDAO method: insertJobExecutionParam(..)");

        KeyHolder holder = new GeneratedKeyHolder();
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(jobExecutionParamQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setLong(j++, maxJobExecutionID);
                ps.setString(j++, "STRING");
                ps.setString(j++, "FileName");
                ps.setString(j++, fileDetails.getFileName());
                ps.setInt(j++, 0);
                ps.setInt(j++, 0);
                ps.setString(j++, "Y");
                return ps;
            }
        }, holder);
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(jobExecutionParamQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setLong(j++, maxJobExecutionID);
                ps.setString(j++, "STRING");
                ps.setString(j++, "srcPath");
                ps.setString(j++, fileDetails.getSrcPath());
                ps.setInt(j++, 0);
                ps.setInt(j++, 0);
                ps.setString(j++, "Y");
                return ps;
            }
        }, holder);
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(jobExecutionParamQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setLong(j++, maxJobExecutionID);
                ps.setString(j++, "STRING");
                ps.setString(j++, "destPath");
                ps.setString(j++, fileDetails.getDestPath());
                ps.setInt(j++, 0);
                ps.setInt(j++, 0);
                ps.setString(j++, "Y");
                return ps;
            }
        }, holder);
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(jobExecutionParamQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setLong(j++, maxJobExecutionID);
                ps.setString(j++, "STRING");
                ps.setString(j++, "File Created Time");
                ps.setString(j++, fileDetails.getCeateTime());
                ps.setInt(j++, 0);
                ps.setInt(j++, 0);
                ps.setString(j++, "Y");
                return ps;
            }
        }, holder);
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(jobExecutionParamQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setLong(j++, maxJobExecutionID);
                ps.setString(j++, "STRING");
                ps.setString(j++, "File Modified Time");
                ps.setString(j++, fileDetails.getModifiedTime());
                ps.setInt(j++, 0);
                ps.setInt(j++, 0);
                ps.setString(j++, "Y");
                return ps;
            }
        }, holder);

        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: insertJobExecutionParam(..)");
    }

    public void updateJobEndTime() {
        FocusConfig.getCurrentLogger().writeDebug("Start: FileDAO method: updateJobEndTime(..)");

        KeyHolder holder = new GeneratedKeyHolder();
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(jobEndTimeQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setLong(j++, maxJobExecutionID);
                return ps;
            }
        }, holder);

        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: updateJobEndTime(..)");
    }

    public void updateJobEcecutionStatus(final String status,long JobExecutionID) {
        FocusConfig.getCurrentLogger().writeDebug("Start: FileDAO method: updateJobEcecutionStatus(..)");

        KeyHolder holder = new GeneratedKeyHolder();
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(statusUpdateQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setString(j++, status);
                ps.setLong(j++, JobExecutionID);
                return ps;
            }
        }, holder);

        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: updateJobEcecutionStatus(..)");
    }

    public void updateExitCodeQuery(final String status) {
        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: updateExitCodeQuery(..)");

        KeyHolder holder = new GeneratedKeyHolder();
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(exitCodeQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setString(j++, status);
                ps.setLong(j++, maxJobExecutionID);
                return ps;
            }
        }, holder);

        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: updateExitCodeQuery(..)");
    }

    public void updateExitMessageQuery(final String status) {
        FocusConfig.getCurrentLogger().writeDebug("Start: FileDAO method: updateExitMessageQuery(..)");

        KeyHolder holder = new GeneratedKeyHolder();
        jdbcTemplate.update(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(exitMessageQuery, Statement.RETURN_GENERATED_KEYS);
                int j = 1;
                ps.setString(j++, status);
                ps.setLong(j++, maxJobExecutionID);
                return ps;
            }
        }, holder);

        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: updateExitMessageQuery(..)");
    }

    public List<FileDetails> getFnameAndExecutionIDQuery() {
        FocusConfig.getCurrentLogger().writeDebug("Start: FileDAO method: getFnameAndExecutionIDQuery(..)");
        List<FileDetails> list =jdbcTemplate.query(new PreparedStatementCreator() {
            public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
                PreparedStatement ps = con.prepareStatement(getFnameAndExecutionIDQuery, Statement.RETURN_GENERATED_KEYS);
                return ps;
            }
        }, new FileMapper());
        FocusConfig.getCurrentLogger().writeDebug("End: FileDAO method: getFnameAndExecutionIDQuery(..)");
        return list;
    }
}
