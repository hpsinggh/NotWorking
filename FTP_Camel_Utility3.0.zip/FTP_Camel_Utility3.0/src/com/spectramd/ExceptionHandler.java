/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd;

import com.spectramd.products.focus.common.FocusConfig;
import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.List;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 *
 * @author heerendra.singh
 */
public class ExceptionHandler implements Processor {

    private FileDAO fileDAO;

    public ExceptionHandler(FileDAO fileDAO) {
        this.fileDAO = fileDAO;
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        FocusConfig.getCurrentLogger().writeDebug("Start: alternate path for exception: ExceptionProcessor method: process(..)");
        Exception e = (Exception) exchange.getProperty("CamelExceptionCaught");
        StringWriter errors = new StringWriter();
        e.printStackTrace(new PrintWriter(errors));
        FocusConfig.getCurrentLogger().writeDebug(errors);
        
        File file = exchange.getIn().getBody(File.class);
        List<FileDetails> list=fileDAO.getFnameAndExecutionIDQuery();
        Iterator i = list.iterator();
        FileDetails fileDetails;
         while(i.hasNext()) 
         {
         fileDetails=(FileDetails)i.next();
         if(file.getName()==fileDetails.getFileName())
         {
         fileDAO.updateJobEcecutionStatus("FAILED",fileDetails.getExecution_ID());
         fileDAO.jobFailed(errors,fileDetails.getExecution_ID());
         }
         }
    }
}
