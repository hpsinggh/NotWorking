/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd;

import com.spectramd.products.focus.common.FocusConfig;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author heerendra.singh
 */
public class SuccessfulFileTransfer {
    private FileDAO fileDAO;

    public void setFileDAO(FileDAO fileDAO) {
        this.fileDAO = fileDAO;
    }

    public FileDAO getFileDAO() {
        return fileDAO;
    }

    public void updateStatus()
    {
        FocusConfig.getCurrentLogger().writeDebug("Start: SuccessfulFileTransfer updateStatus()");
        List<FileDetails> list = fileDAO.getFnameAndExecutionIDQuery();
        System.out.println("\n\n\n\n"+list+"\n\n\n\n\n");
        Iterator i = list.iterator();
        FileDetails fileDetails;
       while (i.hasNext()) {
            
            fileDetails = (FileDetails) i.next();
            System.out.println("\n\n\n"+fileDetails+"\n\n\n");
            System.out.println("\n"+fileDetails.getFileName()+": saved file name is "+RouteProcessor.fileName);
            System.out.println("\n"+fileDetails.getExecution_ID()+"\n\n\n");
            
//            if (RouteProcessor.fileName == fileDetails.getFileName()) {
////                fileDAO.updateJobEcecutionStatus("COMPLETE",fileDetails.getExecution_ID());
//                System.out.println("true for "+fileDetails.getFileName());
//            }
        }
        FocusConfig.getCurrentLogger().writeDebug("End: SuccessfulFileTransfer updateStatus()");
    }
}
