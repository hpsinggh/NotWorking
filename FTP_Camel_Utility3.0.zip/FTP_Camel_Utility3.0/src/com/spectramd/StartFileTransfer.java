package com.spectramd;

import com.spectramd.products.focus.agent.FocusArgConfigInitializer;
import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusDefaultLogInitializer;
import com.spectramd.products.focus.common.FocusLogger;
import com.spectramd.products.focus.common.utils.ThreadUtils;
import java.io.PrintWriter;
import java.io.StringWriter;
import org.apache.camel.CamelContext;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

/**
 *
 * @author heerendra.singh
 */
public class StartFileTransfer  {

    private static FileDAO fileDAO;
    public static void main(String[] args) throws Exception {
        try {
            ThreadUtils.initializeInheritableThread();
            String[] client = {"client", "spectramedix"};
            FocusArgConfigInitializer.initialize(client);
            FocusLogger.info("Configuration Intialized");
            // 2. Initialize the logger
            FocusDefaultLogInitializer init = new FocusDefaultLogInitializer();
            init.Initialize(null);
            FocusLogger.info("Logger Initialized");
            FocusConfig.getCurrentLogger().writeDebug("Start: StartFileTransfer method: main(..)");
            ApplicationContext context=new FileSystemXmlApplicationContext("config/application-context.xml");
            fileDAO = context.getBean("fileDAO", FileDAO.class);
            fileDAO.insertJobInstance();
            CamelContext ctx = context.getBean("camelcontext", CamelContext.class);
//            ctx.start();
//            ctx.startRoute("route1");
//            Thread.sleep(5000);
//            ctx.stop();
            ctx.start();
//            ctx.startRoute("route2");
            Thread.sleep(5000);
            ctx.stop();
        } catch (Exception e) {
            FocusLogger.error("Error in StartFileTransfer: ", e);
//            StringWriter errors = new StringWriter();
//            e.printStackTrace(new PrintWriter(errors));
//            FocusConfig.getCurrentLogger().writeDebug(errors);
//            fileDAO.jobFailed(errors);
        }
//        fileDAO.jobCompleted();
        FocusConfig.getCurrentLogger().writeDebug("End: StartFileTransfer method: main(..)");
    }
}
